# File calc.py

# Function defined in module
def average(list):

    return float(sum(list)) / len(list)
